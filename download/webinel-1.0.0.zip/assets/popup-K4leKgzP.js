import{a as e,c as t,i as n,l as r,n as i,o as a,r as o,s,t as c,u as l}from"./ConfirmDialog-BmJQTKEh.js";import{_ as u,a as d,c as f,d as p,g as m,h,o as g,p as _}from"./config-DWk1CYpU.js";import{C as v,L as y,N as b,P as x,S,_ as C,a as w,b as ee,c as T,g as E,h as D,i as O,j as te,m as k,n as A,o as j,p as ne,r as M,u as re,v as ie,x as ae}from"./WhitelistStore-vulrQAlO.js";function oe(e){if(e===null)return null;if(e<1024)return`${e} B`;let t=[`KB`,`MB`,`GB`],n=e/1024,r=0;for(;n>=1024&&r<t.length-1;)n/=1024,r+=1;return`${n.toFixed(+(n<10))} ${t[r]}`}function N(e){return e===null?null:new Date(e).toLocaleString(void 0,{year:`numeric`,month:`short`,day:`numeric`,hour:`2-digit`,minute:`2-digit`})}function se(e){return e===null?null:new Date(e).toLocaleDateString(void 0,{year:`numeric`,month:`short`,day:`numeric`})}function ce(e){let t=Math.max(0,Math.round(e/1e3));return t<60?`${t}s`:`${Math.floor(t/60)}m ${String(t%60).padStart(2,`0`)}s`}function le(e){return[e===`file`?{label:`Uploading file`,phases:[`uploading`]}:{label:`Submitting URL`,phases:[`submitting`]},{label:`Queued at VirusTotal`,phases:[`queued`]},{label:`Vendors analyzing`,phases:[`in-progress`]},{label:`Building full report`,phases:[`fetching-report`]}]}function ue(t,n=Date.now()){let r=le(t.kind),i=r.findIndex(e=>e.phases.includes(t.phase)),a=t.report?.vendors.length??0,o=r.map((e,t)=>`<li class="analysis-progress__step" data-state="${t<i?`done`:t===i?`active`:`pending`}"><i class="analysis-progress__dot"></i>${e.label}</li>`).join(``),s=[`Elapsed ${ce(n-t.startedAt)}`,t.polls>0?`${t.polls} check${t.polls===1?``:`s`}`:null,a>0?`${a} vendors reported`:null].filter(Boolean).join(` · `);return`<section class="analysis-progress glass" data-phase="${t.phase}" aria-live="polite">
    <div class="analysis-progress__head">
      <div>
        <h3 class="analysis-progress__title">Analyzing ${e(t.target)}</h3>
        <p class="analysis-progress__detail" data-role="elapsed">${e(s)}</p>
      </div>
      <button class="btn" type="button" data-action="cancel-analysis" data-job="${t.id}">Cancel</button>
    </div>
    <div class="analysis-progress__bar"><span></span></div>
    <ol class="analysis-progress__steps">${o}</ol>
    <p class="analysis-progress__hint">You can close this popup — polling continues in the background and respects VirusTotal’s rate limit.</p>
  </section>`}var de={"missing-key":`key`,"invalid-key":`key`,forbidden:`lock`,"rate-limited":`timeline`,offline:`globe`,"file-too-large":`document`,"unsupported-file":`document`,"invalid-url":`search`},fe={"open-settings":`Open Settings`,retry:`Try again`};function P(t){let n=t.action?`<button class="btn ${t.action===`open-settings`?`btn--primary`:``}" type="button" data-error-action="${t.action}">${fe[t.action]}</button>`:``;return`<section class="error-state glass" role="alert" data-error="${t.code}">
    <span class="error-state__icon">${o(de[t.code]??`shieldAlert`,26)}</span>
    <h3 class="error-state__title">${e(t.title)}</h3>
    <p class="error-state__message">${e(t.message)}</p>
    ${n}
  </section>`}function F(e,t){e.querySelector(`[data-error-action="open-settings"]`)?.addEventListener(`click`,()=>t.openSettings?.()),e.querySelector(`[data-error-action="retry"]`)?.addEventListener(`click`,()=>t.retry?.())}function I(t,n={}){return`<dl class="meta-grid">${t.filter(e=>!n.hideEmpty||e.value!==null&&e.value!==void 0&&e.value!==``).map(t=>{let n=t.value===null||t.value===void 0||t.value===``,r=n?`—`:String(t.value);return`<div class="meta-grid__row">
        <dt class="meta-grid__label">${e(t.label)}</dt>
        <dd class="meta-grid__value${t.mono?` mono`:``}${n?` meta-grid__value--empty`:``}" title="${e(r)}">${e(r)}</dd>
      </div>`}).join(``)}</dl>`}var pe={safe:`Safe`,suspicious:`Suspicious`,dangerous:`Dangerous`,unknown:`Unverified`,error:`Check failed`},me={safe:`Safe`,warning:`Warning`,blocked:`Blocked`,unknown:`Unverified`},he={safe:`safe`,warning:`warn`,blocked:`danger`,unknown:`unknown`},ge={safe:`safe`,suspicious:`warn`,dangerous:`danger`,unknown:`unknown`,error:`unknown`};function _e(e){return pe[e]}function L(e){return ge[e]}function R(t,n=`Not checked`){return t?`<span class="chip chip--${ge[t]}" data-verdict="${t}"><i class="chip__dot"></i>${pe[t]}</span>`:`<span class="chip chip--unknown">${e(n)}</span>`}function ve(e){return`<span class="chip chip--${he[e]}" data-status="${e}"><i class="chip__dot"></i>${me[e]}</span>`}var z=42,ye=2*Math.PI*z;function be(e,t,n,r=112){let i=e.total>0?e.detected/e.total:0,a=e.detected>0?Math.max(i*ye,10):0;return`<div class="detection-circle" data-tone="${L(t)}" data-state="${n}" role="img" aria-label="${n===`processing`&&e.total===0?`Analysis in progress, no vendor results yet`:`${e.detected} of ${e.total} security vendors flagged this${n===`complete`?``:` so far`}`}">
    <svg width="${r}" height="${r}" viewBox="0 0 100 100" aria-hidden="true">
      <circle class="detection-circle__track" cx="50" cy="50" r="${z}" fill="none" stroke-width="7"/>
      <circle class="detection-circle__arc" cx="50" cy="50" r="${z}" fill="none" stroke-width="7" stroke-linecap="round"
        stroke-dasharray="${a.toFixed(2)} ${ye.toFixed(2)}" transform="rotate(-90 50 50)"/>
    </svg>
    <div class="detection-circle__text">
      <strong class="detection-circle__detected">${e.detected}</strong>
      <span class="detection-circle__total">/ ${e.total}</span>
    </div>
  </div>`}var xe={complete:null,partial:`Analysis still running — showing vendors that have finished`,processing:`Queued at VirusTotal — no vendor results yet`};function B(t,n){let r=[],i=xe[t.state];return i&&r.push(`<p class="result-header__notice" data-notice="state">${i}</p>`),t.stale?r.push(`<p class="result-header__notice result-header__notice--warn" data-notice="stale">Offline — showing an older cached result. It is not a fresh scan.</p>`):t.source===`cache`&&r.push(`<p class="result-header__notice" data-notice="cache">From Smart Cache</p>`),`<header class="result-header glass" data-verdict="${t.verdict}">
    <div class="result-header__top">
      ${be(t.ratio,t.verdict,t.state)}
      <div class="result-header__subject">
        <div class="result-header__chips">${R(t.verdict)}</div>
        <h2 class="result-header__title" title="${e(n.title)}">${e(n.title)}</h2>
        ${n.subtitle?`<p class="result-header__subtitle mono" title="${e(n.subtitle)}">${e(n.subtitle)}</p>`:``}
        <p class="result-header__caption">security vendors flagged this${t.state===`complete`?``:` so far`}</p>
      </div>
    </div>
    ${r.join(``)}
    ${I(n.items)}
  </header>`}var Se={malicious:`Malicious`,suspicious:`Suspicious`,clean:`Clean`,undetected:`Undetected`},Ce={malicious:`danger`,suspicious:`warn`,clean:`safe`,undetected:`unknown`},we={timeout:`Timeout`,"confirmed-timeout":`Timeout`,"type-unsupported":`Unsupported`,failure:`Failed`};function Te(e){return e.verdict===`undetected`&&we[e.category]?we[e.category]:(e.verdict===`malicious`||e.verdict===`suspicious`)&&e.label?e.label:Se[e.verdict]}function Ee(e){let t={malicious:0,suspicious:0,clean:0,undetected:0};for(let n of e)t[n.verdict]+=1;return t}function V(t,n={}){if(t.length===0)return`<div class="vendor-table vendor-table--empty"><p class="empty-state">No antivirus results yet.</p></div>`;let r=n.scroll?1/0:n.limit??12,i=Ee(t),a=Object.keys(i).filter(e=>i[e]>0).map(e=>`<span class="chip chip--${Ce[e]}">${i[e]} ${Se[e]}</span>`).join(``),o=t.map((t,n)=>`<tr class="vendor-table__row" data-verdict="${t.verdict}"${n>=r?` hidden`:``}>
        <td class="vendor-table__engine">${e(t.engine)}</td>
        <td class="vendor-table__verdict"><span class="chip chip--${Ce[t.verdict]}" title="${e(t.label??t.category)}"><i class="chip__dot"></i>${e(Te(t))}</span></td>
      </tr>`).join(``),s=t.length>r?`<button class="btn btn--block vendor-table__more" type="button" data-action="toggle-vendors" data-limit="${r}" aria-expanded="false">Show all ${t.length} vendors</button>`:``,c=`<table>
      <thead><tr><th scope="col">Antivirus</th><th scope="col">Verdict</th></tr></thead>
      <tbody>${o}</tbody>
    </table>`;return n.scroll?`<div class="vendor-table vendor-table--scroll">
    <div class="vendor-table__summary">${a}</div>
    <div class="vendor-table__scroll scroll" tabindex="0" role="region" aria-label="All ${t.length} antivirus vendors">${c}</div>
    <p class="vendor-table__count">${t.length} vendors · scroll to see all</p>
  </div>`:`<div class="vendor-table">
    <div class="vendor-table__summary">${a}</div>
    ${c}
    ${s}
  </div>`}function H(e){for(let t of e.querySelectorAll(`[data-action="toggle-vendors"]:not([data-bound])`)){t.dataset.bound=`true`;let e=t.closest(`.vendor-table`).querySelectorAll(`.vendor-table__row`).length;t.addEventListener(`click`,()=>{let n=t.getAttribute(`aria-expanded`)===`true`,r=Number(t.dataset.limit);t.closest(`.vendor-table`).querySelectorAll(`.vendor-table__row`).forEach((e,t)=>{e.hidden=n&&t>=r}),t.setAttribute(`aria-expanded`,String(!n)),t.textContent=n?`Show all ${e} vendors`:`Show fewer`})}}function U(t,n,r){return`<section class="report-section" data-section="${r}">
    <h3 class="section-title">${e(t)}</h3>
    <div class="report-section__body glass">${n}</div>
  </section>`}function W(t){return`<p class="report-section__empty">${e(t)}</p>`}function De(e){return e===null?null:String(e)}function Oe(e,t){let n=e.url,r=[{label:`URL`,value:n?.url,mono:!0},{label:`Domain`,value:n?.domain},{label:`IP address`,value:n?.ipAddresses.join(`, `)||null,mono:!0},{label:`HTTP status`,value:De(n?.httpStatus??null)},{label:`Content type`,value:n?.contentType}];return t&&r.push({label:`First seen`,value:N(e.firstSeen)}),r.push({label:`Last analysis`,value:e.state===`complete`?N(e.lastAnalysisDate):`In progress`}),r}function G(t){return t.permalink?`<button class="btn" type="button" data-action="open-permalink" data-href="${e(t.permalink)}">${o(`external`,13)}View on VirusTotal</button>`:``}function ke(e){return`<div class="report" data-kind="url" data-state="${e.state}">
    ${B(e,{title:e.url?.domain??`URL`,subtitle:e.url?.title,items:Oe(e,!1)})}
    ${U(`Antivirus vendors`,V(e.vendors,{limit:10}),`vendors`)}
    <div class="report__actions">${G(e)}</div>
  </div>`}function Ae(e){let t=e.votes;return U(`Community reputation`,I([{label:`Community score`,value:t?String(t.harmless-t.malicious):null},{label:`Reputation`,value:e.reputation??e.domain?.reputation??null},{label:`Votes`,value:t?`${t.harmless} harmless · ${t.malicious} malicious`:null}]),`reputation`)}function K(t,n,r){return t.length===0?W(r):`<div class="chip-list">${t.map(t=>`<span class="chip chip--${n}">${e(t)}</span>`).join(``)}</div>`}function je(t){let n=t.domain?.dns??[];return U(`DNS`,n.length?`<table class="record-table"><thead><tr><th scope="col">Type</th><th scope="col">Value</th><th scope="col">TTL</th></tr></thead><tbody>${n.map(t=>`<tr><td>${e(t.type)}</td><td class="mono">${e(t.value)}</td><td>${t.ttl??`—`}</td></tr>`).join(``)}</tbody></table>`:W(`No DNS records reported.`),`dns`)}function Me(e){let t=e.domain?.certificate;return U(`SSL certificate`,t?I([{label:`Issuer`,value:t.issuer},{label:`Subject`,value:t.subject},{label:`Valid from`,value:se(t.validFrom)},{label:`Expiry`,value:se(t.validTo)},{label:`Fingerprint`,value:t.fingerprint,mono:!0}]):W(`No HTTPS certificate on record.`),`certificate`)}function Ne(t){return t.length<2?W(`No redirects — the URL loads directly.`):`<ol class="redirect-timeline">${t.map((n,r)=>`<li class="redirect-timeline__hop" data-final="${r===t.length-1}">
        <span class="redirect-timeline__node"></span>
        <span class="redirect-timeline__url mono" title="${e(n)}">${e(n)}</span>
      </li>`).join(``)}</ol>`}function Pe(e){let t=e.domain?.whois??[];return U(`WHOIS summary`,t.length?I(t):W(`No public WHOIS details.`),`whois`)}function Fe(t){return t.raw?`<details class="raw-metadata glass">
    <summary>Raw metadata</summary>
    <pre class="mono">${e(t.raw)}</pre>
  </details>`:``}function Ie(e){let t=[...new Set([...e.categories,...e.domain?.categories??[]])];return`<div class="report report--full" data-kind="url" data-state="${e.state}">
    ${B(e,{title:e.url?.domain??`URL`,subtitle:e.url?.title,items:Oe(e,!0)})}
    ${U(`Threat classification`,K(e.threats,`danger`,`No threat classification — no vendor labelled a threat type.`),`threats`)}
    ${Ae(e)}
    ${U(`Antivirus vendors`,V(e.vendors,{scroll:!0}),`vendors`)}
    ${U(`Categories`,K(t,`accent`,`No categories reported.`),`categories`)}
    ${U(`Redirect chain`,Ne(e.url?.redirectChain??[]),`redirects`)}
    ${je(e)}
    ${Me(e)}
    ${Pe(e)}
    ${Fe(e)}
    <div class="report__actions">${G(e)}</div>
  </div>`}function Le(e){let t=e.file,n=[{label:`Filename`,value:t?.fileName},{label:`SHA-256`,value:t?.sha256,mono:!0},{label:`MIME type`,value:t?.mimeType,mono:!0},{label:`File type`,value:t?.fileType},{label:`File size`,value:oe(t?.size??null)},{label:`Last analysis`,value:e.state===`complete`?N(e.lastAnalysisDate):`In progress`}];return`<div class="report" data-kind="file" data-state="${e.state}">
    ${B(e,{title:t?.fileName??`File`,items:n})}
    ${e.threats.length?U(`Threat classification`,K(e.threats,`danger`,``),`threats`):``}
    ${U(`Antivirus vendors`,V(e.vendors,{limit:10}),`vendors`)}
    ${Fe(e)}
    <div class="report__actions">${G(e)}</div>
  </div>`}function q(e){for(let t of e.querySelectorAll(`[data-action="open-permalink"]:not([data-bound])`))t.dataset.bound=`true`,t.addEventListener(`click`,()=>{let e=t.dataset.href??``;e.startsWith(`https://www.virustotal.com/`)&&chrome.tabs.create({url:e})})}function Re(t,n){return`<header class="screen-header">
    <button class="icon-btn" type="button" data-action="back" aria-label="Back">${o(`back`,18)}</button>
    <span class="screen-header__icon">${o(n,18)}</span>
    <h1 class="screen-header__title">${e(t)}</h1>
  </header>`}function J(e,t,n,r){let i=e.querySelector(`[data-slot="header"]`);i&&(i.outerHTML=Re(t,n),e.querySelector(`[data-action="back"]`)?.addEventListener(`click`,r))}async function Y(){let[e]=await chrome.tabs.query({active:!0,currentWindow:!0});if(!e?.id)return null;let t=e.url??``,n=S(t);return{id:e.id,url:t,title:e.title??``,host:n?ae(t):null,scannable:n}}function ze(e){return`<footer class="popup-footer">
    <span data-role="version">v${e}</span>
    <span class="popup-footer__sep">•</span>
    <a href="#" data-legal="privacy">Privacy</a>
    <span class="popup-footer__sep">•</span>
    <a href="#" data-legal="terms">Terms</a>
  </footer>`}function Be(){try{return chrome.runtime.getManifest().version}catch{return`0.0.0`}}function X(e,t){let n=e.querySelector(`[data-slot="footer"]`);if(n){n.outerHTML=ze(Be());for(let n of e.querySelectorAll(`[data-legal]`))n.addEventListener(`click`,e=>{e.preventDefault(),t(n.dataset.legal)})}}var Z=new Map;function Ve(e,t){Z.set(e,t)}function He(e){let t=Z.get(e);return Z.delete(e),t??null}var Ue=`<div data-slot="header"></div>

<div class="screen-body scroll analysis">
  <form class="inline-form" data-role="form" autocomplete="off" novalidate>
    <input class="input mono" data-role="url" type="text" inputmode="url" placeholder="https://example.com/login" aria-label="URL to analyze" spellcheck="false" />
    <button class="btn btn--primary" type="submit" data-action="analyze"><span data-icon="analysis" data-icon-size="14"></span>Analyze</button>
  </form>
  <button class="analysis__current" type="button" data-action="current-site" disabled>
    <span data-icon="globe" data-icon-size="14"></span>
    <span class="analysis__current-label">Current site</span>
    <span class="analysis__current-host mono" data-role="current-host">No website open</span>
  </button>
  <p class="analysis__note">
    Complete analysis: the URL is submitted to VirusTotal (visible to its community) and Webinel waits until every vendor has finished.
  </p>

  <div data-role="job" aria-live="polite"></div>

  <div class="analysis__quick">
    <button class="btn" type="button" data-action="scan-email"><span data-icon="mail" data-icon-size="14"></span>Scan email links</button>
    <button class="btn" type="button" data-action="scan-clipboard"><span data-icon="clipboard" data-icon-size="14"></span>Scan clipboard</button>
  </div>

  <section class="glass links" data-role="links" hidden></section>

  <section>
    <h3 class="section-title">Redirect chain · current tab</h3>
    <div class="glass redirects" data-role="redirects"></div>
  </section>
</div>

<div data-slot="footer"></div>
`;function We(e,t=Date.now()){if(y.has(e.phase)){let n=e.report?.vendors.length?`<div class="analysis__partial"><h3 class="section-title">Vendors finished so far</h3><div class="report-section__body glass">${V(e.report.vendors,{scroll:!0})}</div></div>`:``;return ue(e,t)+n}return e.phase===`completed`&&e.report?Ie(e.report):P(e.error??x(`server-error`))}function Ge(t,n){return t.total===0?`<div class="empty-state">${o(`mail`,20)}<span>No links found.</span></div>`:`<div class="links__label"><span>${e(n)}</span><span>${t.total} link${t.total===1?``:`s`}</span></div>
    <div class="links__summary">${[`dangerous`,`suspicious`,`unknown`,`error`,`safe`].filter(e=>t.counts[e]>0).map(e=>`<span class="chip chip--${L(e)}">${t.counts[e]} ${_e(e)}</span>`).join(``)}</div>
    <ul class="list">${t.items.slice(0,30).map(t=>`<li class="list-row">
          <div class="list-row__main">
            <div class="list-row__title">${e(t.host)}</div>
            <div class="list-row__meta" title="${e(t.url)}">${e(t.reasons[0]??t.url)}</div>
          </div>
          ${R(t.verdict)}
        </li>`).join(``)}</ul>`}function Ke(t){if(t.length===0)return`<div class="empty-state"><span>No redirects on the last page load.</span></div>`;let n=t.map(t=>`<div class="hop"><span class="hop__code">${t.statusCode}</span><span class="hop__url" title="${e(t.from)}">${e(t.from)}</span></div>`),r=t[t.length-1];return n.push(`<div class="hop"><span class="hop__code">END</span><span class="hop__url" title="${e(r.to)}">${e(r.to)}</span></div>`),(t.length>=3?`<p class="redirects__warning">${t.length} hops — long redirect chains are common in phishing.</p>`:``)+n.join(``)}async function qe(e,t){e.innerHTML=Ue,a(e,(e,t)=>o(e,t)),J(e,`Advanced Analysis`,`analysis`,t.back),X(e,t.navigate);let n=s(e,`[data-role="form"]`),r=s(e,`[data-role="url"]`),c=s(e,`[data-action="analyze"]`),l=s(e,`[data-role="job"]`),u=s(e,`[data-role="links"]`),d=await Y().catch(()=>null),f=null,p=``,g=e=>{f=null,p=``,l.innerHTML=P(e),F(l,{openSettings:()=>t.navigate(`settings`),retry:()=>void v()})},_=(e,n=!1)=>{if(!e||e.id!==f)return;let r=y.has(e.phase);c.disabled=r;let i=r?`${e.phase}:${e.polls}:${e.updatedAt}:${Math.floor(Date.now()/1e3)}`:`${e.id}:${e.phase}`;if(i===p&&!n)return;p=i;let a=l.querySelector(`.vendor-table__scroll`)?.scrollTop??0;l.innerHTML=We(e);let o=l.querySelector(`.vendor-table__scroll`);o&&(o.scrollTop=a),H(l),q(l),F(l,{openSettings:()=>t.navigate(`settings`),retry:()=>void v()})},v=async()=>{let e;try{e=ie(r.value)}catch{g(x(`invalid-url`));return}r.value=e,c.disabled=!0;try{let t=await h(`analysis:start-url`,{url:e});t.kind===`job`?(f=t.jobId,_(await C.find(f),!0)):t.kind===`error`&&g(t.error)}catch{g(x(`server-error`))}finally{f||(c.disabled=!1)}};n.addEventListener(`submit`,e=>{e.preventDefault(),v()});let b=s(e,`[data-action="current-site"]`);d?.scannable&&d.host?(b.disabled=!1,b.title=`Analyze ${d.url}`,s(e,`[data-role="current-host"]`).textContent=d.host):b.title=`Open a website in this tab to analyze it`,b.addEventListener(`click`,()=>{d?.scannable&&(r.value=d.url,v())}),l.addEventListener(`click`,async e=>{let t=e.target.closest(`[data-action="cancel-analysis"]`);t?.dataset.job&&(t.disabled=!0,await h(`analysis:cancel`,{jobId:t.dataset.job}).catch(()=>void 0))});let S=He(`advancedUrl`);if(S)r.value=S.url,S.autostart&&v();else{let e=await C.latest(`url`);e?(f=e.id,r.value=e.target,_(e,!0)):d?.scannable&&(r.value=d.url)}let w=C.subscribe(e=>_(f?e[f]??null:null)),T=window.setInterval(async()=>{if(!f)return;let e=await C.find(f);e&&y.has(e.phase)&&_(e)},1e3),E=async(e,t)=>{u.hidden=!1,u.innerHTML=`<div class="empty-state"><span>Checking ${e.length} link${e.length===1?``:`s`}…</span></div>`;try{u.innerHTML=Ge(await h(`scan:links`,{urls:e}),t)}catch(e){u.hidden=!0,i(e instanceof Error?e.message:`Link scan failed`,`error`)}},D=await m.get(),O=s(e,`[data-action="scan-email"]`),k=s(e,`[data-action="scan-clipboard"]`);O.title=D.emailLinkScanner?`Check every link in the open email`:`Enable Email Link Scanner in Settings`,k.title=D.clipboardScanner?`Check links you copied`:`Enable Clipboard Scanner in Settings`,O.addEventListener(`click`,async()=>{if(!D.emailLinkScanner)return i(`Turn on Email Link Scanner in Settings first.`,`info`);if(!d?.scannable)return i(`Open an email in this tab first.`,`info`);try{let[e]=await chrome.scripting.executeScript({target:{tabId:d.id},func:te});await E(e?.result??[],`Email links`)}catch{i(`This page cannot be scanned.`,`error`)}}),k.addEventListener(`click`,async()=>{if(!D.clipboardScanner)return i(`Turn on Clipboard Scanner in Settings first.`,`info`);try{let e=ee(await navigator.clipboard.readText());if(e.length===0)return i(`No links found in the clipboard.`,`info`);if(e.length===1)return r.value=e[0],i(`Link pasted — press Analyze for a full report.`,`info`);await E(e,`Clipboard links`)}catch{i(`Clipboard access was denied.`,`error`)}});let A=s(e,`[data-role="redirects"]`);return A.innerHTML=Ke(d?await h(`tab:redirects`,{tabId:d.id}).catch(()=>[]):[]),()=>{w(),window.clearInterval(T)}}var Q=new class extends u{constructor(){super(`bookmarks`,()=>[])}add(e,t){let n=v(e),r=n?ae(n):null;return!n||!r?Promise.reject(Error(`Only http(s) pages can be bookmarked.`)):this.update(e=>e.some(e=>e.url===n)?e:[{id:crypto.randomUUID(),title:t.trim().slice(0,120)||r,url:n,host:r,createdAt:Date.now(),lastVerdict:null,lastCheckedAt:null},...e])}remove(e){return this.update(t=>t.filter(t=>t.id!==e))}markChecked(e,t){return this.update(n=>n.map(n=>n.id===e?{...n,lastVerdict:t,lastCheckedAt:Date.now()}:n))}},Je=`<div data-slot="header"></div>

<div class="screen-body">
  <p class="muted bookmarks__intro">Secure Bookmarks re-check a site before opening it.</p>
  <button class="btn btn--primary btn--block" type="button" data-action="add-current">
    <span data-icon="plus" data-icon-size="14"></span><span data-role="add-label">Bookmark current site</span>
  </button>
  <h3 class="section-title">Saved <span data-role="count"></span></h3>
  <div class="glass panel scroll">
    <ul class="list" data-role="list"></ul>
  </div>
</div>

<div data-slot="footer"></div>
`;function Ye(t,n){s(t,`[data-role="count"]`).textContent=String(n.length);let r=s(t,`[data-role="list"]`);if(n.length===0){r.innerHTML=`<li class="empty-state">${o(`bookmark`,22)}<span>No secure bookmarks yet.</span></li>`;return}r.innerHTML=n.map(t=>{let n=t.lastCheckedAt?`checked ${_(t.lastCheckedAt)}`:`not checked yet`;return`<li class="list-row bookmark-row" data-open="${t.id}" tabindex="0" role="button" aria-label="Open ${e(t.title)}">
        <span class="row-icon">${o(`bookmark`,14)}</span>
        <div class="list-row__main">
          <div class="list-row__title">${e(t.title)}</div>
          <div class="list-row__meta">${e(t.host)} · ${e(n)}</div>
        </div>
        ${R(t.lastVerdict,`New`)}
        <div class="row-actions">
          <button class="icon-btn" type="button" data-remove="${t.id}" aria-label="Remove bookmark" title="Remove">${o(`trash`,14)}</button>
        </div>
      </li>`}).join(``)}async function Xe(e,t){t.setAttribute(`aria-busy`,`true`);try{let t=await h(`scan:url`,{url:e.url,scope:`domain`});if(await Q.markChecked(e.id,t.verdict),t.verdict===`dangerous`){i(`Not opened: ${t.reasons[0]??`this site is now flagged as dangerous`}`,`error`,4e3);return}if(t.verdict===`suspicious`&&!await c({title:`${e.host} looks suspicious`,message:t.reasons[0]??`Webinel found warning signs on this site.`,confirmLabel:`Open anyway`,cancelLabel:`Stay here`,tone:`danger`}))return;await chrome.tabs.create({url:e.url})}catch(e){i(e instanceof Error?e.message:`Could not check bookmark`,`error`)}finally{t.removeAttribute(`aria-busy`)}}async function Ze(e,t){e.innerHTML=Je,a(e,(e,t)=>o(e,t)),J(e,`Secure Bookmarks`,`bookmark`,t.back),X(e,t.navigate);let n=await Y().catch(()=>null),r=s(e,`[data-action="add-current"]`);r.disabled=!n?.scannable,n?.host&&(s(e,`[data-role="add-label"]`).textContent=`Bookmark ${n.host}`),r.addEventListener(`click`,async()=>{if(n?.scannable)try{await Q.add(n.url,n.title),i(`Bookmark saved`,`success`)}catch(e){i(e instanceof Error?e.message:`Could not save bookmark`,`error`)}});let c=s(e,`[data-role="list"]`),l=async e=>{let t=e.target,n=t.closest(`[data-remove]`);if(n){await Q.remove(n.dataset.remove);return}let r=t.closest(`[data-open]`),i=r&&(await Q.get()).find(e=>e.id===r.dataset.open);r&&i&&await Xe(i,r)};return c.addEventListener(`click`,e=>void l(e)),c.addEventListener(`keydown`,e=>{e.key===`Enter`&&e.target.matches(`[data-open]`)&&l(e)}),Ye(e,await Q.get()),Q.subscribe(t=>Ye(e,t))}var Qe=`<div data-slot="header"></div>

<div class="screen-body scroll documents">
  <label class="dropzone glass" data-role="dropzone" tabindex="0">
    <input type="file" data-role="file" hidden />
    <span class="dropzone__icon" data-icon="upload" data-icon-size="26"></span>
    <strong>Drop a file or click to choose</strong>
    <small>PDF · DOCX · XLSX · ZIP · EXE · APK · PNG · JPG · GIF · TXT — up to 32 MB</small>
    <small>Files are fingerprinted on this device. Only the SHA-256 is checked; nothing is uploaded unless you say so.</small>
    <small class="dropzone__hint" data-role="picker-hint" hidden>Clicking opens a small Webinel scanner window, because your browser closes this popup while its file chooser is open. Dragging a file here works directly.</small>
  </label>

  <div data-role="result" aria-live="polite"></div>
  <section class="glass links" data-role="links" hidden></section>
</div>

<div data-slot="footer"></div>
`,$e={staging:T},et=`popup/index.html?mode=window`;function tt(){let e=new URLSearchParams(location.search).get(`mode`);return e===`window`||e===`panel`?e:`popup`}function nt(){let e=globalThis.browser?.sidebarAction;return typeof e?.open==`function`?e:null}function rt(){let e=chrome.sidePanel;return typeof e?.open==`function`?e:null}function it(){return typeof globalThis.browser?.runtime?.getBrowserInfo==`function`}async function at(){return tt()!==`popup`||!it()&&await chrome.runtime.getPlatformInfo().then(e=>e.os).catch(()=>null)===`mac`?`inline`:nt()||rt()?`panel`:`window`}function ot(e){let t;try{let n=nt(),r=rt();if(n)t=n.open();else if(r&&e!==null)t=r.open({windowId:e});else throw Error(`No side panel available`)}catch{st();return}t.then(()=>window.close(),()=>void st())}async function st(){let e=chrome.runtime.getURL(et),t=(await chrome.tabs.query({}).catch(()=>[])).find(t=>t.url?.startsWith(e));t?.windowId===void 0?await chrome.windows.create({url:`${e}#documents`,type:`popup`,width:440,height:600,focused:!0}):await chrome.windows.update(t.windowId,{focused:!0}),window.close()}function ct(e){return`<section class="consent glass" data-role="consent">
    <div class="consent__head">
      <span class="consent__icon">${o(`upload`,20)}</span>
      <h3 class="consent__title">VirusTotal has never seen this file</h3>
    </div>
    <p class="consent__text">Upload it so 70+ antivirus engines can analyze it? Uploaded files are shared with VirusTotal and its security partners and may be downloaded by them. <strong>Do not upload private or confidential documents.</strong></p>
    ${I([{label:`Filename`,value:e.fileName},{label:`SHA-256`,value:e.sha256,mono:!0},{label:`File size`,value:oe(e.size)}])}
    <div class="consent__buttons">
      <button class="btn" type="button" data-action="decline-upload">Don't upload</button>
      <button class="btn btn--primary" type="button" data-action="approve-upload">${o(`upload`,13)}Upload to VirusTotal</button>
    </div>
  </section>`}function lt(t){return`<section class="declined glass" data-role="declined">
    <div>${R(`unknown`)}</div>
    <p><strong>${e(t.fileName)}</strong> was not uploaded. VirusTotal has no record of this exact file, so Webinel cannot vouch for it — treat it with care.</p>
    <button class="btn" type="button" data-action="reconsider">Upload after all</button>
  </section>`}function ut(e){return y.has(e.phase)?ue(e):e.phase===`completed`&&e.report?Le(e.report):P(e.error??x(`server-error`))}async function dt(t,n){t.innerHTML=Qe,a(t,(e,t)=>o(e,t)),J(t,`Document Scanner`,`document`,n.back),X(t,n.navigate);let r=s(t,`[data-role="dropzone"]`),i=s(t,`[data-role="file"]`),c=s(t,`[data-role="result"]`),l=s(t,`[data-role="links"]`);i.accept=ne;let u=await at(),d=s(t,`[data-role="picker-hint"]`);u!==`inline`&&(d.textContent=u===`panel`?`Clicking opens the scanner in your browser’s side panel, because the browser closes this popup while its file chooser is open. Dragging a file here works directly.`:`Clicking opens a small Webinel scanner window, because your browser closes this popup while its file chooser is open. Dragging a file here works directly.`,d.hidden=!1);let f=null;u===`panel`&&chrome.windows.getCurrent().then(e=>{f=e.id??null}).catch(()=>void 0);let p=()=>{u===`panel`?ot(f):st()},m=null,g=``,_=null,v=()=>{H(c),q(c),F(c,{openSettings:()=>n.navigate(`settings`),retry:()=>_&&void A(_.file)})},S=e=>{m=null,c.innerHTML=P(e),v()},w=(e,t=!1)=>{if(!e||e.id!==m)return;let n=y.has(e.phase)?`${e.phase}:${e.polls}:${e.updatedAt}:${Math.floor(Date.now()/1e3)}`:`${e.id}:${e.phase}`;(n!==g||t)&&(g=n,c.innerHTML=ut(e),v())},T=async()=>{if(!_)return;let{meta:t,file:n}=_;c.innerHTML=`<p class="documents__working">Preparing ${e(t.fileName)} for upload…</p>`;try{let e;try{e=await $e.staging.put(n)}catch{S(x(`upload-handoff`));return}let r=await h(`file:upload`,{meta:t,stagingId:e,consent:!0});r.kind===`job`?(m=r.jobId,w(await C.find(m),!0)):r.kind===`error`&&S(r.error)}catch{S(x(`server-error`))}},O=e=>{c.innerHTML=ct(e);let t=s(c,`[data-action="approve-upload"]`),n=s(c,`[data-action="decline-upload"]`);t.addEventListener(`click`,()=>{t.disabled=!0,n.disabled=!0,T()}),n.addEventListener(`click`,()=>{c.innerHTML=lt(e),s(c,`[data-action="reconsider"]`).addEventListener(`click`,()=>O(e))})},te=async e=>{if(k(e.name)!==`txt`)return;let t=ee(await e.text());if(t.length!==0){l.hidden=!1,l.innerHTML=`<div class="empty-state"><span>Checking ${t.length} links…</span></div>`;try{l.innerHTML=Ge(await h(`scan:links`,{urls:t}),`Links in document`)}catch{l.hidden=!0}}},A=async t=>{m=null,_=null,l.hidden=!0;try{E({fileName:t.name,size:t.size})}catch(e){S(e instanceof b?e.info:x(`unsupported-file`));return}c.innerHTML=`<p class="documents__working">Fingerprinting ${e(t.name)} on this device…</p>`;try{let e={fileName:t.name,sha256:await re(t),size:t.size,mimeType:D(t.name,t.type)};_={meta:e,file:t};let n=await h(`file:lookup`,e);n.kind===`report`?(c.innerHTML=`<p class="documents__known">${o(`check`,13)}VirusTotal already has this exact file, so no upload is needed.</p>${Le(n.report)}`,v()):n.kind===`needs-upload`?O(e):S(n.error),await te(t)}catch{S(x(`server-error`))}finally{i.value=``}};r.addEventListener(`click`,e=>{u!==`inline`&&(e.preventDefault(),p())}),i.addEventListener(`change`,()=>{let e=i.files?.[0];e&&A(e)}),r.addEventListener(`keydown`,e=>{(e.key===`Enter`||e.key===` `)&&(e.preventDefault(),u===`inline`?i.click():p())}),r.addEventListener(`dragover`,e=>{e.preventDefault(),r.dataset.dragging=`true`}),r.addEventListener(`dragleave`,()=>delete r.dataset.dragging),r.addEventListener(`drop`,e=>{e.preventDefault(),delete r.dataset.dragging;let t=e.dataTransfer?.files[0];t&&A(t)}),c.addEventListener(`click`,async e=>{let t=e.target.closest(`[data-action="cancel-analysis"]`);t?.dataset.job&&(t.disabled=!0,await h(`analysis:cancel`,{jobId:t.dataset.job}).catch(()=>void 0))});let j=await C.latest(`file`);j&&y.has(j.phase)&&(m=j.id,w(j,!0));let M=C.subscribe(e=>w(m?e[m]??null:null)),ie=window.setInterval(async()=>{if(!m)return;let e=await C.find(m);e&&y.has(e.phase)&&w(e)},1e3);return()=>{M(),window.clearInterval(ie)}}var ft=`<header class="home-header">
  <div class="brand">
    <span class="brand__logo" data-slot="logo"></span>
    <div class="brand__text">
      <h1 class="brand__name">Webinel</h1>
      <p class="brand__tagline">Your Web Sentinel</p>
    </div>
  </div>
  <button class="icon-btn home-header__settings" type="button" data-action="settings" aria-label="Settings" title="Settings">
    <span data-icon="settings" data-icon-size="17"></span>
  </button>
</header>

<div class="home-body">
  <section class="protection" data-role="protection" data-state="on" aria-label="Protection status">
    <div class="protection__scope" aria-hidden="true">
      <span class="protection__sweep"></span>
      <span class="protection__ring protection__ring--outer"></span>
      <span class="protection__ring protection__ring--inner"></span>
      <span class="protection__badge" data-role="shield-icon"></span>
    </div>
    <div class="protection__info">
      <p class="protection__domain" data-role="domain" title="">Checking current tab…</p>
      <h2 class="protection__title" data-role="title">You're Protected</h2>
      <p class="protection__realtime"><i class="protection__live"></i><span data-role="realtime">Real-time Protection ON</span></p>
      <div class="protection__site">
        <span data-role="site-verdict"></span>
        <button class="btn btn--primary protection__scan" type="button" data-action="scan">
          <span data-icon="search" data-icon-size="14"></span><span>Scan now</span>
        </button>
      </div>
    </div>
    <button class="protection__setup" type="button" data-action="setup-key" hidden>
      <span data-icon="key" data-icon-size="13"></span>
      <span>Add a free VirusTotal key for reputation checks</span>
      <span class="protection__setup-cta">Set up</span>
    </button>
  </section>

  <nav class="tile-grid" aria-label="Webinel tools">
    <button class="tile glass" type="button" data-go="whitelist">
      <span class="tile__icon" data-icon="whitelist" data-icon-size="15"></span><span class="tile__label">Whitelist</span>
    </button>
    <button class="tile glass" type="button" data-go="statistics">
      <span class="tile__icon" data-icon="statistics" data-icon-size="15"></span><span class="tile__label">Statistics</span>
    </button>
    <button class="tile glass" type="button" data-go="bookmarks">
      <span class="tile__icon" data-icon="bookmark" data-icon-size="15"></span><span class="tile__label">Bookmarks</span>
    </button>
    <button class="tile glass" type="button" data-go="advanced">
      <span class="tile__icon" data-icon="analysis" data-icon-size="15"></span><span class="tile__label">Advanced Analysis</span>
    </button>
    <button class="tile glass" type="button" data-go="documents">
      <span class="tile__icon" data-icon="document" data-icon-size="15"></span><span class="tile__label">Document Scanner</span>
    </button>
    <button class="tile glass" type="button" data-go="timeline">
      <span class="tile__icon" data-icon="timeline" data-icon-size="15"></span><span class="tile__label">Timeline</span>
    </button>
  </nav>

  <section class="activity" aria-label="Recent activity">
    <h3 class="section-title">Recent Activity</h3>
    <div class="activity__panel glass scroll">
      <ul class="list" data-role="activity"></ul>
    </div>
  </section>
</div>

<div data-slot="footer"></div>
`;function pt(t,n,r=Date.now()){if(n.length===0){t.innerHTML=`<li class="empty-state">${o(`globe`,22)}<span>No activity yet — browse and Webinel will report here.</span></li>`;return}t.innerHTML=n.map(t=>`<li class="list-row" data-host="${e(t.host)}">
        <span class="activity__site-icon">${o(`globe`,14)}</span>
        <div class="list-row__main">
          <div class="list-row__title">${e(t.host)}</div>
          <div class="list-row__meta">${e(_(t.timestamp,r))}</div>
        </div>
        ${ve(t.status)}
      </li>`).join(``)}function mt(e,t){return e.realTimeProtection?t===`dangerous`?`danger`:t===`suspicious`?`warn`:`on`:`off`}var ht={on:`You're Protected`,off:`Protection Paused`,warn:`Be careful on this page`,danger:`Threat on this page`},gt={on:`shieldCheck`,off:`shieldAlert`,warn:`shieldAlert`,danger:`shieldAlert`};function _t(e,t,n=null){let r=s(e,`[data-role="protection"]`),i=mt(t,n);r.dataset.state=i,s(e,`[data-role="title"]`).textContent=ht[i],s(e,`[data-role="realtime"]`).textContent=t.realTimeProtection?`Real-time Protection ON`:`Real-time Protection OFF`,s(e,`[data-role="shield-icon"]`).innerHTML=o(gt[i],34)}function vt(e,t,n){let r=s(e,`[data-role="domain"]`);r.textContent=t?.host??`No website open`,r.title=t?.host??``,s(e,`[data-role="site-verdict"]`).innerHTML=t?.scannable?R(n,`Not checked yet`):`<span class="chip chip--unknown">Nothing to scan</span>`}async function yt(e,t){e.innerHTML=ft,a(e,(e,t)=>o(e,t)),s(e,`[data-slot="logo"]`).innerHTML=n(34,`home`),X(e,t.navigate),s(e,`[data-action="settings"]`).addEventListener(`click`,()=>t.navigate(`settings`));for(let n of e.querySelectorAll(`[data-go]`))n.addEventListener(`click`,()=>t.navigate(n.dataset.go));let r=await m.get();_t(e,r);let i=s(e,`[data-role="activity"]`);pt(i,await j.get());let c=await Y().catch(()=>null),l=null;if(c?.scannable){let e=await h(`tab:current-report`,{tabId:c.id}).catch(()=>null);e&&e.host===c.host&&(l=e.verdict)}vt(e,c,l),_t(e,r,l);let u=s(e,`[data-action="setup-key"]`);u.addEventListener(`click`,()=>t.navigate(`settings`)),h(`apiKey:status`,{}).then(({configured:e})=>{u.hidden=e}).catch(()=>void 0),s(e,`[data-action="scan"]`).addEventListener(`click`,()=>{c?.scannable&&Ve(`scanUrl`,{url:c.url,autostart:!0}),t.navigate(`scan`)});let d=[m.subscribe(t=>{r=t,_t(e,r,l)}),j.subscribe(e=>pt(i,e))];return()=>d.forEach(e=>e())}var bt=`<div data-slot="header"></div>

<div class="legal-tabs segmented" role="tablist" aria-label="Legal">
  <button class="legal-tabs__tab segmented__option" type="button" role="tab" id="legal-tab-privacy" data-section="privacy" aria-controls="legal-privacy">Privacy</button>
  <button class="legal-tabs__tab segmented__option" type="button" role="tab" id="legal-tab-terms" data-section="terms" aria-controls="legal-terms">Terms</button>
</div>

<div class="screen-body legal-body scroll" data-role="scroller" tabindex="0">
  <section class="legal-doc glass" id="legal-privacy" role="tabpanel" aria-labelledby="legal-tab-privacy" data-panel="privacy">
    <h2 class="legal-doc__title">Privacy</h2>
    <p class="legal-doc__lead">Protect first. Respect privacy always.</p>
    <ul class="legal-doc__list">
      <li>Webinel has <strong>no servers, no accounts and no sign-in</strong>. Everything it stores stays in your browser on this device.</li>
      <li>The only outside service is <strong>VirusTotal</strong>, and only when you add your own API key. There is no telemetry and no analytics. Webinel sends VirusTotal the <em>domain</em> of sites you open and — only when you ask — a full address or a document's SHA-256 fingerprint.</li>
      <li>Links are submitted to VirusTotal for new analysis only when you run <em>Scan Now</em> on a link it has not seen before, or <em>Advanced Analysis</em>. Submitted links become visible to the VirusTotal community.</li>
      <li>Files are uploaded only if you press <em>Upload to VirusTotal</em> for that file. Uploaded files are shared with VirusTotal and its security partners — do not upload confidential documents.</li>
      <li>Your API key is encrypted, stored locally, never synchronised, never shown again after saving, and sent only to VirusTotal to authenticate.</li>
      <li>Webinel never stores email bodies, raw clipboard contents or your browsing history. Cached results are keyed by one-way hashes and contain no addresses or file names; the timeline records security events by domain or file name only.</li>
      <li>The Email Link Scanner and Clipboard Scanner run only when you turn them on and press scan. They read links — never message text.</li>
      <li>Removing the extension deletes all of its data.</li>
    </ul>
  </section>

  <section class="legal-doc glass" id="legal-terms" role="tabpanel" aria-labelledby="legal-tab-terms" data-panel="terms">
    <h2 class="legal-doc__title">Terms</h2>
    <p class="legal-doc__lead">One edition. Every feature included.</p>
    <ul class="legal-doc__list">
      <li>Webinel is provided "as is", without warranty. No security tool catches every threat; a Safe or Unverified result is not a guarantee.</li>
      <li>Your use of VirusTotal is governed by VirusTotal's own terms of service and API limits.</li>
      <li>You are responsible for sites you choose to whitelist or continue to after a warning.</li>
      <li>There is a single edition of Webinel. Every feature is included.</li>
    </ul>
    <p class="legal-doc__note">Status: TBD — this plain-language draft has not yet been reviewed by counsel.</p>
  </section>
</div>

<div data-slot="footer"></div>
`,xt={privacy:`Privacy`,terms:`Terms`};function St(e,t){for(let n of e.querySelectorAll(`[data-section]`)){let e=n.dataset.section===t;n.setAttribute(`aria-selected`,String(e)),n.tabIndex=e?0:-1}for(let n of e.querySelectorAll(`[data-panel]`))n.hidden=n.dataset.panel!==t;let n=e.querySelector(`.screen-header__title`);n&&(n.textContent=xt[t]),s(e,`[data-role="scroller"]`).scrollTop=0}function Ct(e,t,n){e.innerHTML=bt,J(e,xt[n],`lock`,t.back),X(e,t=>St(e,t));for(let t of e.querySelectorAll(`[data-section]`))t.addEventListener(`click`,()=>St(e,t.dataset.section));St(e,n)}var wt=`<div data-slot="header"></div>

<div class="screen-body scroll scan-now">
  <form class="inline-form" data-role="form" autocomplete="off" novalidate>
    <input class="input mono" data-role="url" type="text" inputmode="url" placeholder="Paste a link to scan" aria-label="URL to scan" spellcheck="false" />
    <button class="btn btn--primary" type="submit" data-action="scan"><span data-icon="search" data-icon-size="14"></span>Scan</button>
  </form>
  <p class="scan-now__note">
    Quick verdict in about 6 seconds. Links VirusTotal has never seen are submitted there and become visible to its community.
  </p>
  <div class="scan-timer" data-role="timer" hidden><span></span></div>
  <div data-role="result" aria-live="polite">
    <ol class="scan-steps" aria-label="How Scan Now checks a link">
      <li class="scan-steps__item">
        <span class="scan-steps__num">1</span>
        <div><strong>Local checks</strong><span>Look-alike domains, raw IPs, punycode and risky extensions — on this device.</span></div>
      </li>
      <li class="scan-steps__item">
        <span class="scan-steps__num">2</span>
        <div><strong>VirusTotal reputation</strong><span>70+ security vendors, using your own API key.</span></div>
      </li>
      <li class="scan-steps__item">
        <span class="scan-steps__num">3</span>
        <div><strong>Verdict in about 6 seconds</strong><span>Need every vendor? Continue with Advanced Analysis.</span></div>
      </li>
    </ol>
  </div>
  <button class="btn btn--block" type="button" data-action="full-analysis" hidden>
    <span data-icon="analysis" data-icon-size="14"></span>Run complete Advanced Analysis
  </button>
</div>

<div data-slot="footer"></div>
`;function Tt(e,t){if(t.kind===`report`){e.innerHTML=ke(t.report),H(e),q(e);return}e.innerHTML=P(t.kind===`error`?t.error:x(`server-error`))}async function Et(t,n){t.innerHTML=wt,a(t,(e,t)=>o(e,t)),J(t,`Scan Now`,`search`,n.back),X(t,n.navigate);let r=s(t,`[data-role="form"]`),i=s(t,`[data-role="url"]`),c=s(t,`[data-action="scan"]`),l=s(t,`[data-role="timer"]`),u=s(t,`[data-role="result"]`),d=s(t,`[data-action="full-analysis"]`),p=async()=>{d.hidden=!0;let t;try{t=ie(i.value)}catch{Tt(u,{kind:`error`,error:x(`invalid-url`)});return}i.value=t,c.disabled=!0,l.hidden=!1,l.classList.remove(`scan-timer--running`),l.offsetWidth,l.classList.add(`scan-timer--running`),u.innerHTML=`<div class="scan-now__waiting"><strong>Checking ${e(new URL(t).hostname)}…</strong><span>Collecting antivirus results for up to ${f.quickScanDeadlineMs/1e3} seconds</span></div>`;try{let e=await h(`scan:quick`,{url:t});Tt(u,e),d.hidden=e.kind!==`report`}catch{Tt(u,{kind:`error`,error:x(`server-error`)})}finally{c.disabled=!1,l.hidden=!0,l.classList.remove(`scan-timer--running`)}F(u,{openSettings:()=>n.navigate(`settings`),retry:()=>void p()})};r.addEventListener(`submit`,e=>{e.preventDefault(),p()}),d.addEventListener(`click`,()=>{Ve(`advancedUrl`,{url:i.value,autostart:!0}),n.navigate(`advanced`)});let m=He(`scanUrl`);if(m){i.value=m.url,m.autostart&&p();return}let g=await Y().catch(()=>null);g?.scannable&&(i.value=g.url),i.focus()}var Dt=class{outlet;screens;current=null;cleanup=null;history=[];constructor(e,t){this.outlet=e,this.screens=t}get active(){return this.current}navigate=e=>{this.current&&this.history.push(this.current),this.show(e,!1)};back=()=>{this.show(this.history.pop()??`home`,!0)};async show(e,t){this.cleanup?.(),this.cleanup=null,this.current=e;let n=document.createElement(`section`);n.className=`screen screen--${e}${t?` screen--back`:``}`,n.dataset.screen=e,this.outlet.replaceChildren(n);let r;try{r=await this.screens[e](n,{navigate:this.navigate,back:this.back})}catch(t){console.warn(`Webinel: could not open ${e}`,t),this.current===e&&this.renderFailure(n,e);return}this.current===e&&typeof r==`function`?this.cleanup=r:typeof r==`function`&&r()}renderFailure(e,t){e.innerHTML=`<div class="screen-error" role="alert">
      <strong>This screen could not load</strong>
      <span>Webinel's background service may be restarting. Try again in a moment.</span>
      <button class="btn" type="button" data-action="retry">Try again</button>
      ${t===`home`?``:`<button class="btn btn--ghost" type="button" data-action="home">Back to Home</button>`}
    </div>`,e.querySelector(`[data-action="retry"]`)?.addEventListener(`click`,()=>void this.show(t,!1)),e.querySelector(`[data-action="home"]`)?.addEventListener(`click`,()=>{this.history.length=0,this.show(`home`,!0)})}},Ot=`<div data-slot="header"></div>

<div class="screen-body scroll settings">
  <section class="vt-card glass" aria-labelledby="vt-title">
    <div class="vt-card__row">
      <span class="vt-card__icon" data-icon="key" data-icon-size="18"></span>
      <div class="vt-card__main">
        <h2 class="vt-card__title" id="vt-title">VirusTotal API</h2>
        <p class="vt-card__secret mono" data-role="secret" aria-label="API key hidden">••••••••••••••••</p>
      </div>
      <div class="vt-card__actions">
        <button class="icon-btn" type="button" data-action="edit-key" aria-label="Edit API key" title="Edit API key">
          <span data-icon="pencil" data-icon-size="16"></span>
        </button>
        <button class="icon-btn" type="button" data-action="check-health" aria-label="Check API reachability" title="Check API reachability">
          <span data-icon="refresh" data-icon-size="16"></span>
        </button>
      </div>
    </div>
    <p class="vt-card__subtitle">
      <span data-icon="lock" data-icon-size="12"></span>Stored locally on this device.
      <span class="vt-card__health" data-role="health" data-state="idle"></span>
    </p>

    <form class="vt-editor" data-role="editor" hidden autocomplete="off">
      <label class="vt-editor__label" for="vt-key-input">Paste your VirusTotal API key</label>
      <input
        class="input mono"
        id="vt-key-input"
        data-role="key-input"
        type="password"
        spellcheck="false"
        autocomplete="off"
        inputmode="text"
        maxlength="128"
        placeholder="64-character key"
      />
      <div class="vt-editor__buttons">
        <button class="btn" type="button" data-action="remove-key" hidden>Remove key</button>
        <span class="vt-editor__spacer"></span>
        <button class="btn" type="button" data-action="cancel-key">Cancel</button>
        <button class="btn btn--primary" type="submit" data-action="save-key">Save</button>
      </div>
      <p class="vt-editor__hint">Get a free key at virustotal.com → your profile → API key. It never leaves this device except to authenticate with VirusTotal.</p>
    </form>
  </section>

  <section>
    <h3 class="section-title">Protection</h3>
    <div class="glass settings-group">
      <label class="setting-row">
        <span class="setting-row__icon" data-icon="bolt" data-icon-size="16"></span>
        <span class="setting-row__text"><strong>Real-time Protection</strong><small>Check every site you open</small></span>
        <input class="switch" type="checkbox" data-setting="realTimeProtection" />
      </label>
      <label class="setting-row">
        <span class="setting-row__icon" data-icon="shieldAlert" data-icon-size="16"></span>
        <span class="setting-row__text"><strong>Block suspicious sites</strong><small>Treat suspicious like dangerous</small></span>
        <input class="switch" type="checkbox" data-setting="blockSuspicious" />
      </label>
      <label class="setting-row">
        <span class="setting-row__icon" data-icon="download" data-icon-size="16"></span>
        <span class="setting-row__text"><strong>Download Reputation Scanner</strong><small>Stop disguised and risky files</small></span>
        <input class="switch" type="checkbox" data-setting="downloadScanner" />
      </label>
    </div>
  </section>

  <section>
    <h3 class="section-title">Scanners</h3>
    <div class="glass settings-group">
      <label class="setting-row">
        <span class="setting-row__icon" data-icon="clipboard" data-icon-size="16"></span>
        <span class="setting-row__text"><strong>Clipboard Scanner</strong><small>Scan copied links only when you ask</small></span>
        <input class="switch" type="checkbox" data-setting="clipboardScanner" />
      </label>
      <label class="setting-row">
        <span class="setting-row__icon" data-icon="mail" data-icon-size="16"></span>
        <span class="setting-row__text"><strong>Email Link Scanner</strong><small>Check links in an open email — never its text</small></span>
        <input class="switch" type="checkbox" data-setting="emailLinkScanner" />
      </label>
    </div>
  </section>

  <section>
    <h3 class="section-title">Appearance &amp; Support</h3>
    <div class="glass settings-group">
      <div class="setting-row">
        <span class="setting-row__icon" data-role="theme-icon"></span>
        <span class="setting-row__text"><strong id="theme-label">Theme</strong><small data-role="theme-label">Match your system</small></span>
        <div class="segmented theme-picker" role="radiogroup" aria-labelledby="theme-label">
          <button class="segmented__option" type="button" role="radio" data-theme-option="system" aria-checked="true">Auto</button>
          <button class="segmented__option" type="button" role="radio" data-theme-option="dark" aria-checked="false">Dark</button>
          <button class="segmented__option" type="button" role="radio" data-theme-option="light" aria-checked="false">Light</button>
        </div>
      </div>
      <button class="setting-row setting-row--button" type="button" data-action="contact" aria-expanded="false" aria-controls="contact-panel">
        <span class="setting-row__icon" data-icon="message" data-icon-size="16"></span>
        <span class="setting-row__text"><strong>Contact Developer</strong><small>Email the developer — report a bug or a false positive</small></span>
        <span class="setting-row__chevron" data-icon="mail" data-icon-size="14"></span>
      </button>
      <div class="contact-panel" id="contact-panel" data-role="contact-panel" hidden>
        <p class="contact-panel__text">
          Your email app should now open a new message to
          <strong class="mono" data-role="developer-email"></strong>.
        </p>
        <div class="contact-panel__buttons">
          <button class="btn" type="button" data-action="email-again">
            <span data-icon="mail" data-icon-size="13"></span>Email again
          </button>
          <button class="btn btn--primary" type="button" data-action="open-github">
            <span data-icon="external" data-icon-size="13"></span>Visit developer GitHub
          </button>
        </div>
      </div>
      <button class="setting-row setting-row--button" type="button" data-action="clear-cache">
        <span class="setting-row__icon" data-icon="trash" data-icon-size="16"></span>
        <span class="setting-row__text"><strong>Clear Smart Cache</strong><small>Forget cached VirusTotal results</small></span>
      </button>
    </div>
  </section>
</div>

<div data-slot="footer"></div>
`,kt=`••••••••••••••••`,At={checking:`Checking…`,online:`Online`,"no-key":`No key`,"invalid-key":`Invalid key`,"quota-exceeded":`Quota exceeded`,unreachable:`Unreachable`};function jt(e){let t=At[e.state];return e.state===`online`&&e.latencyMs!==null?`${t} · ${e.latencyMs} ms`:t}function Mt(e,t){let n=s(e,`[data-role="secret"]`);n.textContent=t?kt:`No key added`,n.dataset.empty=String(!t),s(e,`[data-action="remove-key"]`).hidden=!t,s(e,`[data-action="check-health"]`).disabled=!t}function $(e,t,n=``){let r=s(e,`[data-role="health"]`);r.dataset.state=t,r.textContent=t===`idle`?``:n||At[t]}var Nt={system:`Match your system`,dark:`Dark`,light:`Light`};function Pt(e,t){for(let n of e.querySelectorAll(`[data-theme-option]`)){let e=n.dataset.themeOption===t.theme;n.setAttribute(`aria-checked`,String(e)),n.tabIndex=e?0:-1}s(e,`[data-role="theme-label"]`).textContent=Nt[t.theme],s(e,`[data-role="theme-icon"]`).innerHTML=o(l(t.theme)===`light`?`sun`:`moon`,16)}async function Ft(e){let[t]=await chrome.tabs.query({active:!0,currentWindow:!0}).catch(()=>[]);if(t?.id!==void 0&&/^https?:/i.test(t.url??``)){await chrome.tabs.update(t.id,{url:e});return}await chrome.tabs.create({url:e})}async function It(){try{return await chrome.permissions.request({permissions:[`clipboardRead`]})}catch{return!1}}async function Lt(e,n){e.innerHTML=Ot,a(e,(e,t)=>o(e,t)),J(e,`Settings`,`settings`,n.back),X(e,n.navigate);let r=s(e,`[data-role="editor"]`),l=s(e,`[data-role="key-input"]`),u=s(e,`[data-action="check-health"]`),{configured:f}=await h(`apiKey:status`,{}).catch(()=>({configured:!1}));Mt(e,f);let g=()=>{l.value=``,r.hidden=!0},_=async()=>{u.disabled=!0,u.classList.add(`icon-btn--spin`),$(e,`checking`);try{let t=await h(`api:health`,{});$(e,t.state,jt(t))}catch{$(e,`unreachable`)}finally{u.classList.remove(`icon-btn--spin`),u.disabled=!1}};s(e,`[data-action="edit-key"]`).addEventListener(`click`,()=>{r.hidden=!r.hidden,l.value=``,r.hidden||l.focus()}),s(e,`[data-action="cancel-key"]`).addEventListener(`click`,g),u.addEventListener(`click`,()=>void _()),r.addEventListener(`submit`,async t=>{t.preventDefault();let n=l.value.trim();if(!n){i(`Paste your API key first.`,`error`);return}let r=await h(`apiKey:set`,{key:n}).catch(e=>({saved:!1,error:e.message}));if(!r.saved){i(r.error??`Could not save the key.`,`error`);return}g(),Mt(e,!0),i(`API key saved on this device.`,`success`),_()}),s(e,`[data-action="remove-key"]`).addEventListener(`click`,async()=>{await c({title:`Remove your VirusTotal key?`,message:`Reputation checks stop until you add a key again. Webinel cannot show the saved key, so keep a copy if you need it.`,confirmLabel:`Remove key`,tone:`danger`})&&(await h(`apiKey:clear`,{}),g(),Mt(e,!1),$(e,`idle`),i(`API key removed.`,`info`))});let v=await m.get();for(let t of e.querySelectorAll(`[data-setting]`)){let e=t.dataset.setting;t.checked=v[e],t.addEventListener(`change`,async()=>{if(e===`clipboardScanner`&&t.checked&&!await It()){t.checked=!1,i(`Clipboard access was not granted.`,`error`);return}await m.patch({[e]:t.checked})})}Pt(e,v);let y=[...e.querySelectorAll(`[data-theme-option]`)],b=async n=>{t(n),Pt(e,await m.patch({theme:n}))};y.forEach((e,t)=>{e.addEventListener(`click`,()=>void b(e.dataset.themeOption)),e.addEventListener(`keydown`,e=>{if(e.key!==`ArrowRight`&&e.key!==`ArrowLeft`)return;e.preventDefault();let n=y[(t+(e.key===`ArrowRight`?1:y.length-1))%y.length];n.focus(),b(n.dataset.themeOption)})});let x=s(e,`[data-action="contact"]`),S=s(e,`[data-role="contact-panel"]`);s(e,`[data-role="developer-email"]`).textContent=d.email;let C=async()=>{try{await Ft(p(Be()))}catch{i(`Could not open your email app. Write to ${d.email}`,`error`,5e3)}};x.addEventListener(`click`,()=>{S.hidden=!1,x.setAttribute(`aria-expanded`,`true`),C()}),s(e,`[data-action="email-again"]`).addEventListener(`click`,()=>void C()),s(e,`[data-action="open-github"]`).addEventListener(`click`,()=>{chrome.tabs.create({url:d.github})}),s(e,`[data-action="clear-cache"]`).addEventListener(`click`,async()=>{let{cleared:e}=await h(`cache:clear`,{});i(`Smart Cache cleared (${e} entr${e===1?`y`:`ies`}).`,`success`)})}var Rt=`<div data-slot="header"></div>

<div class="screen-body scroll stats">
  <div class="stat-grid" data-role="tiles"></div>

  <section>
    <h3 class="section-title">Sites checked · last 7 days</h3>
    <div class="glass stats-chart" data-role="chart" role="img"></div>
  </section>

  <section>
    <h3 class="section-title">Verdicts</h3>
    <ul class="glass list stats-verdicts" data-role="verdicts"></ul>
  </section>

  <section>
    <h3 class="section-title">Engine <span class="muted" data-role="since"></span></h3>
    <ul class="glass list" data-role="counters"></ul>
  </section>
</div>

<div data-slot="footer"></div>
`,zt=new Intl.NumberFormat,Bt=[{label:`Sites checked`,icon:`globe`,value:e=>e.scanned},{label:`Threats blocked`,icon:`shieldAlert`,value:e=>e.counters.blocked},{label:`Warnings shown`,icon:`bolt`,value:e=>e.counters.warned},{label:`Downloads stopped`,icon:`download`,value:e=>e.counters.downloadsBlocked}],Vt=[`safe`,`suspicious`,`dangerous`,`unknown`,`error`],Ht=[{name:`virusTotalRequests`,label:`VirusTotal requests`},{name:`cacheHits`,label:`Smart Cache hits`},{name:`quickScans`,label:`Scan Now checks`},{name:`fullAnalyses`,label:`Full analyses`},{name:`linksScanned`,label:`Links scanned`},{name:`filesScanned`,label:`Documents scanned`},{name:`filesUploaded`,label:`Files uploaded (with consent)`},{name:`bypassed`,label:`Warnings bypassed`}];function Ut(t,n,r=Date.now()){let i=O(n,g.statsDays,r),a=Math.max(1,...i.map(e=>e.scanned));t.setAttribute(`aria-label`,`Sites checked per day: ${i.map(e=>`${e.day} ${e.scanned}`).join(`, `)}`),t.innerHTML=i.map(t=>{let n=new Date(`${t.day}T12:00:00`),r=n.toLocaleDateString(void 0,{weekday:`short`}),i=t.scanned===0?0:Math.max(4,t.scanned/a*100);return`<div class="bar" tabindex="0" data-day="${t.day}">
        <span class="bar__tip">${e(n.toLocaleDateString(void 0,{month:`short`,day:`numeric`}))} · ${t.scanned} checked · ${t.threats} threat${t.threats===1?``:`s`}</span>
        <span class="bar__value">${t.scanned||``}</span>
        <div class="bar__track"><div class="bar__fill" data-height="${i}"></div></div>
        <span class="bar__day">${e(r)}</span>
      </div>`}).join(``);for(let e of t.querySelectorAll(`.bar__fill`))e.style.height=`${e.dataset.height}%`}function Wt(e,t){s(e,`[data-role="tiles"]`).innerHTML=Bt.map(e=>`<div class="glass stat-tile">
      <div class="stat-tile__value">${zt.format(e.value(t))}</div>
      <div class="stat-tile__label">${o(e.icon,13)}${e.label}</div>
    </div>`).join(``),Ut(s(e,`[data-role="chart"]`),t),s(e,`[data-role="verdicts"]`).innerHTML=Vt.map(e=>`<li class="list-row">
      <div class="list-row__main">${R(e)}</div>
      <span class="list-row__value">${zt.format(t.verdicts[e])}</span>
    </li>`).join(``),s(e,`[data-role="counters"]`).innerHTML=Ht.map(e=>`<li class="list-row">
      <div class="list-row__main">${e.label}</div>
      <span class="list-row__value">${zt.format(t.counters[e.name]??0)}</span>
    </li>`).join(``),s(e,`[data-role="since"]`).textContent=`since ${new Date(t.since).toLocaleDateString()}`}async function Gt(e,t){return e.innerHTML=Rt,J(e,`Statistics`,`statistics`,t.back),X(e,t.navigate),Wt(e,await w.get()),w.subscribe(t=>Wt(e,t))}var Kt=`<div data-slot="header"></div>

<div class="screen-body">
  <div class="timeline__filters segmented" role="tablist" aria-label="Filter events">
    <button class="timeline__filter segmented__option" type="button" role="tab" data-filter="all" aria-selected="true">All</button>
    <button class="timeline__filter segmented__option" type="button" role="tab" data-filter="threats" aria-selected="false">Threats</button>
    <button class="timeline__filter segmented__option" type="button" role="tab" data-filter="scans" aria-selected="false">Scans</button>
    <button class="timeline__filter segmented__option" type="button" role="tab" data-filter="changes" aria-selected="false">Changes</button>
  </div>
  <div class="glass panel scroll">
    <ol class="timeline" data-role="list"></ol>
  </div>
  <button class="btn btn--block" type="button" data-action="clear">
    <span data-icon="trash" data-icon-size="14"></span>Clear timeline
  </button>
</div>

<div data-slot="footer"></div>
`,qt={blocked:{label:`Blocked`,icon:`shieldAlert`,group:`threats`},warned:{label:`Warned`,icon:`shieldAlert`,group:`threats`},bypassed:{label:`Warning bypassed`,icon:`bolt`,group:`threats`},"download-blocked":{label:`Download blocked`,icon:`download`,group:`threats`},"download-paused":{label:`Download paused`,icon:`download`,group:`threats`},"manual-scan":{label:`Scanned`,icon:`search`,group:`scans`},"links-scanned":{label:`Links scanned`,icon:`mail`,group:`scans`},"file-scanned":{label:`Document scanned`,icon:`document`,group:`scans`},"full-analysis":{label:`Full analysis`,icon:`analysis`,group:`scans`},"file-uploaded":{label:`File uploaded`,icon:`upload`,group:`scans`},whitelisted:{label:`Trusted`,icon:`whitelist`,group:`changes`},unwhitelisted:{label:`Untrusted`,icon:`whitelist`,group:`changes`},"api-key-changed":{label:`API key`,icon:`key`,group:`changes`}};function Jt(e,t){return t===`all`?e:e.filter(e=>qt[e.kind]?.group===t)}function Yt(t,n,r=Date.now()){if(n.length===0){t.innerHTML=`<li class="empty-state">${o(`timeline`,22)}<span>No security events yet.</span></li>`;return}t.innerHTML=n.map(t=>{let n=qt[t.kind]??{label:t.kind,icon:`shield`},i=t.verdict?L(t.verdict):`accent`;return`<li class="timeline-item" data-kind="${t.kind}">
        <span class="timeline-item__icon" data-tone="${i}">${o(n.icon,14)}</span>
        <div class="timeline-item__body">
          <div class="timeline-item__head">
            <span class="timeline-item__title">${e(n.label)} · ${e(t.subject)}</span>
            <time class="timeline-item__time" datetime="${new Date(t.timestamp).toISOString()}">${e(_(t.timestamp,r))}</time>
          </div>
          <p class="timeline-item__detail">${e(t.detail)}</p>
        </div>
      </li>`}).join(``)}async function Xt(e,t){e.innerHTML=Kt,a(e,(e,t)=>o(e,t)),J(e,`Timeline`,`timeline`,t.back),X(e,t.navigate);let n=s(e,`[data-role="list"]`),r=`all`,l=await M.get(),u=()=>Yt(n,Jt(l,r));for(let t of e.querySelectorAll(`[data-filter]`))t.addEventListener(`click`,()=>{r=t.dataset.filter;for(let n of e.querySelectorAll(`[data-filter]`))n.setAttribute(`aria-selected`,String(n===t));u()});return s(e,`[data-action="clear"]`).addEventListener(`click`,async()=>{await c({title:`Clear the timeline?`,message:`Every recorded security event is deleted from this device. Statistics are kept.`,confirmLabel:`Clear timeline`,tone:`danger`})&&(await M.set([]),i(`Timeline cleared`,`info`))}),u(),M.subscribe(e=>{l=e,u()})}var Zt=`<div data-slot="header"></div>

<div class="screen-body">
  <p class="muted whitelist__intro">Trusted sites are never blocked. Subdomains are included.</p>
  <form class="inline-form" data-role="form" autocomplete="off">
    <input class="input" data-role="input" type="text" placeholder="example.com" aria-label="Domain to trust" spellcheck="false" />
    <button class="btn btn--primary" type="submit"><span data-icon="plus" data-icon-size="14"></span>Add</button>
  </form>
  <button class="btn btn--block" type="button" data-action="add-current" hidden>
    <span data-icon="globe" data-icon-size="14"></span><span data-role="current-label">Trust current site</span>
  </button>
  <h3 class="section-title">Trusted sites <span data-role="count"></span></h3>
  <div class="glass panel scroll">
    <ul class="list" data-role="list"></ul>
  </div>
</div>

<div data-slot="footer"></div>
`;function Qt(t,n){s(t,`[data-role="count"]`).textContent=String(n.length);let r=s(t,`[data-role="list"]`);if(n.length===0){r.innerHTML=`<li class="empty-state">${o(`whitelist`,22)}<span>No trusted sites yet.</span></li>`;return}r.innerHTML=n.map(t=>`<li class="list-row">
        <span class="row-icon">${o(`check`,14)}</span>
        <div class="list-row__main"><div class="list-row__title">${e(t)}</div></div>
        <div class="row-actions">
          <button class="icon-btn" type="button" data-remove="${e(t)}" aria-label="Remove ${e(t)}" title="Remove">${o(`trash`,14)}</button>
        </div>
      </li>`).join(``)}async function $t(e){try{return await h(`whitelist:add`,{host:e}),i(`Trusted ${e}`,`success`),!0}catch(e){return i(e instanceof Error?e.message:`Could not add site`,`error`),!1}}async function en(e,t){e.innerHTML=Zt,a(e,(e,t)=>o(e,t)),J(e,`Whitelist`,`whitelist`,t.back),X(e,t.navigate);let n=s(e,`[data-role="input"]`);s(e,`[data-role="form"]`).addEventListener(`submit`,async e=>{e.preventDefault(),n.value.trim()&&await $t(n.value)&&(n.value=``)}),s(e,`[data-role="list"]`).addEventListener(`click`,async e=>{let t=e.target.closest(`[data-remove]`);t&&(await h(`whitelist:remove`,{host:t.dataset.remove}),i(`Removed ${t.dataset.remove}`,`info`))});let r=await Y().catch(()=>null),c=s(e,`[data-action="add-current"]`),l=await A.get();return r?.host&&(c.hidden=l.includes(r.host),s(e,`[data-role="current-label"]`).textContent=`Trust ${r.host}`,c.addEventListener(`click`,async()=>{await $t(r.host)&&(c.hidden=!0)})),Qt(e,l),A.subscribe(t=>Qt(e,t))}var tn={home:yt,scan:Et,settings:Lt,statistics:Gt,bookmarks:Ze,whitelist:en,timeline:Xt,advanced:qe,documents:dt,privacy:(e,t)=>Ct(e,t,`privacy`),terms:(e,t)=>Ct(e,t,`terms`)};async function nn(){let e=await chrome.windows.getCurrent();if(e.id===void 0)return;let t=window.outerWidth-window.innerWidth,n=window.outerHeight-window.innerHeight;await chrome.windows.update(e.id,{width:440+t,height:600+n})}async function rn(){await r();let e=tt();e!==`popup`&&(document.documentElement.dataset.mode=e),e===`window`&&nn().catch(()=>void 0);let t=location.hash.slice(1),n=new Dt(document.getElementById(`app`),tn);t in tn&&t!==`home`?n.navigate(t):n.show(`home`,!1)}rn();